package ResourceAgent;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.LinkedList;

// Imports (DF)
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPAException;
import jade.proto.AchieveREResponder;
import java.util.logging.Level;
import java.util.logging.Logger;

//imports ContractNet
import jade.proto.ContractNetResponder;
import static jade.tools.sniffer.Agent.i;
import java.util.HashMap;
import java.util.Map;

// TODO

// - Behavior para fazer a Skill (executar)
// - Behaviour para actualizar queue 
// - Devolver Distância

/**
 *
 * @author André
 */
public class ResourceAgent extends Agent{
    
    protected LinkedList<String> mySkills;
    protected String myLocation;
            
    // Product waiting queue
    public Map<String,String> PwQueue = new HashMap();  // Product / Skill
    // Product arrived queue
    public Map<String, String> ParrQueue = new HashMap();   // 
        
    @Override
    protected void setup() {
        //Argumets [0]resource location [1]skills that resource can perform
        Object[] args = getArguments();

        myLocation = (String) args[0];
        mySkills = (LinkedList<String>) args[1];

        try {
            /*******************************************************************
            * DF
            ********************************************************************
            */
            // The PA will then search for TYPE_RA_SKILL
            UtilitiesTS.DFInteraction.RegisterInDF_RA(this, UtilitiesTS.Constants.TYPE_RA_SKILL, mySkills);
        } catch (FIPAException ex) {
            Logger.getLogger(ResourceAgent.class.getName()).log(Level.SEVERE, null, ex);
        }     
        // Launch Behaviours here
        // Contract Net Participant
        this.addBehaviour(new responder(this, MessageTemplate.MatchPerformative(ACLMessage.CFP)));
        // Request Responder (with PA)
        this.addBehaviour(new responderREQ_PA(this, MessageTemplate.MatchPerformative(ACLMessage.REQUEST)));
        // Request Responder (with CLA) - Sk_A available?
        this.addBehaviour(new responderREQ_CLA(this, MessageTemplate.MatchPerformative(ACLMessage.REQUEST)));
        // Request Responder (with CLA) - Execute Sk_A?
        this.addBehaviour(new responderREQ_CLA_exe(this, MessageTemplate.MatchPerformative(ACLMessage.REQUEST)));

    }
    
    /***************************************************************************
     * ContractNet from PA to RA
     ***************************************************************************
     */
    
    /*
        The product agent requests Skill_A, and the RA returns all
        of the Skill_A' queues with the number of waiting products.
        After the PA chooses, the RA returns an aknowledge and the 
        localization of the chosen skill.
    
    PA(Initiator)                          RA(Participant)
                ------------ cfp --------->
                <----- refuse/proposal ----
                ------ reject/accept ----->
                <----- failure or ---------
                         inform done
                         inform result
    */
    
    
    private class responder extends ContractNetResponder{
        
        public responder(Agent a, MessageTemplate mt){
            super(a, mt);
        }
        
        /*
            To send the proposal with the Skill's queue.
        */        
        @Override
        protected ACLMessage handleCfp(ACLMessage cfp) throws RefuseException, FailureException, NotUnderstoodException{
            System.out.println(myAgent.getLocalName() + ": Processing CFP message");
            ACLMessage msg= cfp.createReply();
            msg.setPerformative(ACLMessage.PROPOSE);
            msg.setContent(""+PwQueue.size()); // 
            PwQueue.put(cfp.getSender().getName(), cfp.getContent());
            return msg;
        }
        
        /*
            If the PA accepts the proposal, then the INFORM is sent with
            the location of the skill.
        */  
        @Override 
        protected ACLMessage handleAcceptProposal (ACLMessage cfp, ACLMessage propose, ACLMessage accept) throws FailureException{
            System.out.println(myAgent.getLocalName() + ": Preparing result of CFP");

            ACLMessage msg = cfp.createReply();
            msg.setPerformative(ACLMessage.INFORM);
            msg.setContent(myLocation);
            return msg;
        }
        
        /*
            If the PA refuses, then the Skill is removed from the waiting queue.
        */   
        protected void handleRefuse(ACLMessage refuse) {
            System.out.println("The contract was refused.");
            PwQueue.remove(refuse.getSender().getName());
        }
    }
    
    
    
    
    /***************************************************************************
     * takeDown 
     ***************************************************************************
     */
     
    @Override
    protected void takeDown() {
         try {
            DFService.deregister(this);
        } catch (FIPAException ex) {
            Logger.getLogger(ResourceAgent.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    
    
    /***************************************************************************
     * Request from PA to RA
     ***************************************************************************
     */
    
    /*
        When a Product PA arrives at the station with the pre-sent 
        location, the PA notifies RA. After 10 seconds, the
        skill is performed and the PA is notified.
    
    PA(Initiator)                          RA(Responder)
                ----------- request ------>
                <----- refuse/agree -------
                <----- failure or ---------
                         inform done
                         inform result
    */
    
    private class responderREQ_PA extends AchieveREResponder{
        
        public responderREQ_PA(Agent a, MessageTemplate mt){
            super(a, mt);
        }
        
        /*
            After receiving an "execute" from the PA when it
            reaches the Skill' location. The RA will reply
            with an AGREE and the pwQueue decreases and the Parr increases.
        */  
        @Override
        protected ACLMessage handleRequest(ACLMessage request) throws NotUnderstoodException, RefuseException {
            ACLMessage msg = request.createReply();
            if(request.equals(UtilitiesTS.Constants.REQUEST_EXE))   {
                msg.setPerformative(ACLMessage.AGREE);
                // Add to Arrive
                ParrQueue.put(request.getSender().getName(), PwQueue.get(request.getSender().getName()));
                // Remove from Waiting
                PwQueue.remove(request.getSender().getName());
            }
            else    {
                msg.setPerformative(ACLMessage.REFUSE);
            }
            return msg;
        }
        
        /*
            The Skill will be executed (10 seconds) and after that
            the PA will be notified. The skill is then removed 
            from the QarrQueue.
        */ 
         @Override
        protected ACLMessage prepareResultNotification(ACLMessage request, ACLMessage response) throws FailureException {
            ACLMessage msg = request.createReply();
            msg.setPerformative(ACLMessage.INFORM);
            
            block(10000);
            ParrQueue.remove(request.getSender().getName());
            return msg;
        }
    }
    
    
    
    
    /***************************************************************************
     * ContractNet from CLA to RA - Request Skill
     ***************************************************************************
     */
    
    /*
        CLA Requests specific atomic skill from RA. If the skill is 
        available, then an agree is sent and the skill is added to the waiting
        queue.
    
    CLA(Initiator)                         RA(Responder)
                ----------- request ------>
                <----- refuse/agree -------
                <----- failure or ---------
                         inform done
                         inform result
    
    */
    private class responderREQ_CLA extends AchieveREResponder{
        
        public responderREQ_CLA(Agent a, MessageTemplate mt){
            super(a, mt);
        }
        /*
            If the skill is available, put on the waiting queue and
            reply with an AGREE
        */ 
        @Override
        protected ACLMessage handleRequest(ACLMessage request) throws NotUnderstoodException, RefuseException {
            ACLMessage msg = request.createReply();
            if(PwQueue.containsValue(request.getContent()) || ParrQueue.containsValue(request.getContent()))    
            {
                msg.setPerformative(ACLMessage.REFUSE);
            }
            else    {
                // The skill is added to the waiting queue.
                PwQueue.put(request.getSender().getName(), request.getContent());
                msg.setPerformative(ACLMessage.AGREE);
            }
            return msg;
        }
        
    }
    
    /***************************************************************************
     * ContractNet from CLA to RA - Request execution of skill
     ***************************************************************************
     */
    
    /*
        When the product reaches the location of the Skill, the 
        CLA that contains the atomic skill is notified and then it notifies
        the RA to execute the skill
    
    CLA(Initiator)                         RA(Responder)
                ----------- request ------>
                <----- refuse/agree -------
                <----- failure or ---------
                         inform done
                         inform result
    
    */
    private class responderREQ_CLA_exe extends AchieveREResponder{
        
        public responderREQ_CLA_exe(Agent a, MessageTemplate mt){
            super(a, mt);
        }
        
        /*
            After receiving an "execute" from the CLA when it
            reaches the Skill' location. The RA will reply
            with an AGREE and the pwQueue decreases and the Parr increases.
        */  
        @Override
        protected ACLMessage handleRequest(ACLMessage request) throws NotUnderstoodException, RefuseException {
            ACLMessage msg = request.createReply();
            if(request.equals(UtilitiesTS.Constants.REQUEST_EXE))   {
                msg.setPerformative(ACLMessage.AGREE);
                // Add to Arrive
                ParrQueue.put(request.getSender().getName(), PwQueue.get(request.getSender().getName()));
                // Remove from Waiting
                PwQueue.remove(request.getSender().getName());
            }
            else    {
                msg.setPerformative(ACLMessage.REFUSE);
            }
            return msg;
        }
        
        /*
            The Skill will be executed (10 seconds) and after that
            the CLA will be notified. The skill is then removed 
            from the QarrQueue.
        */ 
         @Override
        protected ACLMessage prepareResultNotification(ACLMessage request, ACLMessage response) throws FailureException {
            ACLMessage msg = request.createReply();
            msg.setPerformative(ACLMessage.INFORM);
            block(10000);
            ParrQueue.remove(request.getSender().getName());
            return msg;
        }
        
    }
    
    /***************************************************************************
     ***************************************************************************
     */
}