/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoalitionLeaderAgent;


import UtilitiesTS.Constants;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.core.behaviours.SequentialBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREInitiator;
import jade.proto.AchieveREResponder;
import jade.proto.ContractNetResponder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Duarte Bragadesto
 * @author José Pinto
 * @author Pedro Rodrigues
 */
public class CoalitionLeaderAgent extends Agent {

    protected String myLocation;
    protected DFAgentDescription[] RAs;
    protected List services;
    protected String services_string;
    protected String[] mySkills;
    protected String[][] RAUseSkills;
    // Product waiting queue (Produto que falta e skill que ele quer)
    public Map<String, String> PwQueue = new HashMap();  // Product / String
    // Product arrived queue
    public Map<String, String> ParrQueue = new HashMap();   // 

    @Override
    protected void setup() {
        //Argumets [0]CLA location
        Object[] args = getArguments();
        //Get my location
        myLocation = (String) args[0];

        //Launch Behaviours here
        SequentialBehaviour seq = new SequentialBehaviour();
        seq.addSubBehaviour(new ReadDFOneShotBehaviour()); //Search in DF here
        seq.addSubBehaviour(new CLARulesOneShotBehaviour()); //Register in DF here
        addBehaviour(seq);

        // ContratNetResponder to PA
        // AchieveREResponder to PA when the produtc is delivered for executation
            // Qual o produto chegou a estação
            // retirar a skill necessaria para o produto
            // ciclo de resquest de skill's ao RA
            // Responder ao PA que a skill foi realizada
            // Eliminar da lista de espera
    }

    //Search in DF 
    class ReadDFOneShotBehaviour extends OneShotBehaviour {

        @Override
        public void action() {

            try {
                RAs = UtilitiesTS.DFInteraction.SearchInDFByType(myLocation, myAgent);
            } catch (FIPAException ex) {
                Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //Register in DF
    class CLARulesOneShotBehaviour extends OneShotBehaviour {

        @Override
        public void action() {

            for (int i = 0; i == RAs.length; i++) {
                Iterator services_it = RAs[i].getAllServices();

                while (services_it.hasNext()) {
                    services_string = services_it.next().toString();
                    services.add(services_string);
                }
            }
            int j = 0;
            if (services.contains("Skill_A") && services.contains("Skill_B") && services.contains("Skill_C") && services.contains("Skill_D")) {
                try {
                    UtilitiesTS.DFInteraction.RegisterInDF(myAgent, "Skill_Z", UtilitiesTS.Constants.TYPE_CLA_SKILL);
                    mySkills[j] = "Skill_Z";
                    RAUseSkills[j][0] = "Skill_A";
                    RAUseSkills[j][1] = "Skill_B";
                    RAUseSkills[j][2] = "Skill_C";
                    RAUseSkills[j][3] = "Skill_D";
                    j++;
                } catch (FIPAException ex) {
                    Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (services.contains("Skill_A") && services.contains("Skill_B")) {
                try {
                    UtilitiesTS.DFInteraction.RegisterInDF(myAgent, "Skill_Y", UtilitiesTS.Constants.TYPE_CLA_SKILL);
                    mySkills[j] = "Skill_Y";
                    RAUseSkills[j][0] = "Skill_A";
                    RAUseSkills[j][1] = "Skill_B";
                    j++;
                } catch (FIPAException ex) {
                    Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (services.contains("Skill_C") && services.contains("Skill_D")) {
                try {
                    UtilitiesTS.DFInteraction.RegisterInDF(myAgent, "Skill_X", UtilitiesTS.Constants.TYPE_CLA_SKILL);
                    mySkills[j] = "Skill_X";
                    RAUseSkills[j][0] = "Skill_C";
                    RAUseSkills[j][1] = "Skill_D";
                    j++;
                } catch (FIPAException ex) {
                    Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (services.contains("Skill_E") && services.contains("Skill_F")) {
                try {
                    UtilitiesTS.DFInteraction.RegisterInDF(myAgent, "Skill_W", UtilitiesTS.Constants.TYPE_CLA_SKILL);
                    mySkills[j] = "Skill_W";
                    RAUseSkills[j][0] = "Skill_E";
                    RAUseSkills[j][1] = "Skill_F";
                    j++;
                } catch (FIPAException ex) {
                    Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (services.contains("Skill_G") && services.contains("Skill_H") && services.contains("Skill_C3")) {
                try {
                    UtilitiesTS.DFInteraction.RegisterInDF(myAgent, "Skill_V", UtilitiesTS.Constants.TYPE_CLA_SKILL);
                    mySkills[j] = "Skill_V";
                    RAUseSkills[j][0] = "Skill_G";
                    RAUseSkills[j][1] = "Skill_H";
                    j++;
                } catch (FIPAException ex) {
                    Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (services.contains("Skill_D") && services.contains("Skill_A")) {
                try {
                    UtilitiesTS.DFInteraction.RegisterInDF(myAgent, "Skill_U", UtilitiesTS.Constants.TYPE_CLA_SKILL);
                    mySkills[j] = "Skill_U";
                    RAUseSkills[j][0] = "Skill_D";
                    RAUseSkills[j][1] = "Skill_A";
                    j++;
                } catch (FIPAException ex) {
                    Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (services.contains("Skill_H") && services.contains("Skill_B")) {
                try {
                    UtilitiesTS.DFInteraction.RegisterInDF(myAgent, "Skill_K", UtilitiesTS.Constants.TYPE_CLA_SKILL);
                    mySkills[j] = "Skill_K";
                    RAUseSkills[j][0] = "Skill_H";
                    RAUseSkills[j][1] = "Skill_B";
                    j++;
                } catch (FIPAException ex) {
                    Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
    }
    
    class execSkiBeh extends SequentialBehaviour{
        public execSkiBeh(Agent a, ACLMessage msg){
            super(a);
        } 
    }
    
    class requestExecutRA extends SimpleBehaviour{
        private int RAs_id=0;
        private boolean finished = false;        
        private int CLA_Skill_ID, RA_Skill_ID;
        private String skill;
        public requestExecutRA(Agent a, String _skill, int _RAs_id, int _CLA_Skill_ID, int _RA_Skill_ID){
            super(a);
            this.RAs_id =_RAs_id;
            this.CLA_Skill_ID = _CLA_Skill_ID;
            this.RA_Skill_ID = _RA_Skill_ID;
            this.skill = _skill;
        }        
        
        @Override
        public void action(){                            
                //send mensage
                ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
                msg.setOntology(UtilitiesTS.Constants.ONTOLOGY_EXECUTE);
                msg.addReceiver(RAs[RAs_id].getName());
                msg.setContent(RAUseSkills[CLA_Skill_ID][RA_Skill_ID]);
                //addBehaviour(new requestRA(myAgent, msg));
                send(msg);
               
        }        
        @Override
        public boolean done(){
            
            ACLMessage msg = myAgent.receive(MessageTemplate.and(MessageTemplate.MatchOntology(Constants.ONTOLOGY_EXECUTE), MessageTemplate.MatchPerformative(ACLMessage.INFORM)));
            //ACLMessage msg = myAgent.receive(MessageTemplate.and(MessageTemplate.MatchOntology(Constants.ONTOLOGY_NEW_PRODUCT), MessageTemplate.MatchPerformative(ACLMessage.INFORM)))
            if(msg != null)
                finished = true;
            return finished;
        }
    }
    
    class InformPA extends SimpleBehaviour{
        private boolean finished = false;
        private ACLMessage msg;
        public InformPA(Agent a, ACLMessage _msg){
            super(a);
            this.msg = _msg;            
        } 
        
        @Override
        public void action(){                            
            //send mensage
            send(msg);
            finished = true;
        }
        
        @Override
        public boolean done(){
            return finished;
        }
    }

    // Contratnet with Product 
    public class CNETResponderToPA extends ContractNetResponder {

        public CNETResponderToPA(Agent a, MessageTemplate mt) {
            super(a, mt);
        }

        /*
            To send the proposal with the Skill's queue.
        */        
        @Override
        protected ACLMessage handleCfp(ACLMessage cfp) throws RefuseException, FailureException, NotUnderstoodException{
            System.out.println(myAgent.getLocalName() + ": Processing CFP message");
            ACLMessage msg= cfp.createReply();
            msg.setPerformative(ACLMessage.PROPOSE);
            msg.setContent(""+PwQueue.size()); // 
            PwQueue.put(cfp.getSender().getName(), cfp.getContent());
            return msg;
        }
        
        /*
            If the PA accepts the proposal, then the INFORM is sent with
            the location of the skill.
        */  
        @Override 
        protected ACLMessage handleAcceptProposal (ACLMessage cfp, ACLMessage propose, ACLMessage accept) throws FailureException{
            System.out.println(myAgent.getLocalName() + ": Preparing result of CFP");
            ACLMessage msg = cfp.createReply();
            msg.setPerformative(ACLMessage.INFORM);
            msg.setContent(myLocation);
            return msg;
        }
        
        /*
            If the PA refuses, then the Skill is removed from the waiting queue.
        */   
        protected void handleRefuse(ACLMessage refuse) {
            System.out.println("The contract was refused.");
            PwQueue.remove(refuse.getSender().getName());
        }
    }

     // Responder ao executar do PA
    private class responderPA extends AchieveREResponder {

        public responderPA(Agent a, MessageTemplate mt) {
            super(a, mt);
        }

        @Override
        protected ACLMessage handleRequest(ACLMessage request) throws NotUnderstoodException, RefuseException {
            ACLMessage msg_1 = request.createReply();
            if (request.getContent().equals("execute")) {
                msg_1.setPerformative(ACLMessage.AGREE);
                // Add to Arrive
                ParrQueue.put(request.getSender().getName(), PwQueue.get(request.getSender().getName()));
                // Remove from Waiting
                PwQueue.remove(request.getSender());
                
                ACLMessage msg2 = request.createReply();
                msg2.setPerformative(ACLMessage.INFORM);
                ParrQueue.remove(request.getSender());
             
                SequentialBehaviour execSkiBeh = new SequentialBehaviour(); //Sequencial Behaviour to send information
                
                int i, CLA_Skill_ID = 0, RA_Skill_ID, RAs_id =0;
                String skill = ParrQueue.get(request.getContent());

                for (i = 0; !RAUseSkills[i][0].equals(skill); i++) {    //search em RAUseSkills e devolve no "i" a skill do CLA
                        CLA_Skill_ID = i;
                }

                for (RA_Skill_ID = 0; RA_Skill_ID < RAUseSkills[CLA_Skill_ID].length; RA_Skill_ID++) {   // percorre o RAUseSkills com todas as skills do RA para a dada skill do CLA
                    // get RA agent with the skill necessary
                    for (int j = 0; j < RAs.length; j++) {
                        Iterator services_it = RAs[CLA_Skill_ID].getAllServices();

                        while (services_it.hasNext()) {
                            if(services_it.next().toString().equals(skill)){
                                RAs_id=j;
                                break;
                            }
                        }
                    }
                    //behaviour to send resquest to RA for execution
                    execSkiBeh.addSubBehaviour(new requestExecutRA(myAgent, skill, RAs_id, CLA_Skill_ID, RA_Skill_ID));                    
                }
                // behaviour to send mensagem with the inform to PA
                execSkiBeh.addSubBehaviour(new InformPA (myAgent, msg2)); 
                // build the sequencial behaviour to execute
                registerPrepareResultNotification(new execSkiBeh(myAgent, msg2));       
            } else {
                msg_1.setPerformative(ACLMessage.REFUSE);
            }
            return msg_1;
        }

        /*
        @Override
        protected ACLMessage prepareResultNotification(ACLMessage request, ACLMessage response) throws FailureException {
            
            int i, CLA_Skill_ID = 0, RA_Skill_ID, RAs_id=0;
            String skill = ParrQueue.get(request.getContent());
            
            for (i = 0; !RAUseSkills[i][0].equals(skill); i++) {    //search em RAUseSkills e devolve no "i" a skill do CLA
                    CLA_Skill_ID = i;
            }

            for (RA_Skill_ID = 0; RA_Skill_ID < RAUseSkills[CLA_Skill_ID].length; RA_Skill_ID++) {   // percorre o RAUseSkills com todas as skills do RA para a dada skill do CLA
                // get RA agent with the skill necessary
                for (int j = 0; j < RAs.length; j++) {
                    Iterator services_it = RAs[CLA_Skill_ID].getAllServices();

                    while (services_it.hasNext()) {
                        if(services_it.next().toString().equals(skill)){
                            RAs_id=j;
                            break;
                        }
                    }

                }
                
                //send mensage
                ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
                msg.setOntology(ONTOLOGY_EXECUTE_RA);
                msg.addReceiver(RAs[RAs_id].getName());
                msg.setContent(RAUseSkills[CLA_Skill_ID][RA_Skill_ID]);
                addBehaviour(new requestRA(myAgent, msg));
                
            }
            
            // esperar que todo seja executado
            
            // Já foi executada
            ACLMessage msg = request.createReply();
            msg.setPerformative(ACLMessage.INFORM);
            block(10000);
            ParrQueue.remove(request.getSender());
            return msg;
        }
*/
    }
    
    // Request skill to RA
    private class requestRA extends AchieveREInitiator {

        public requestRA(Agent a, ACLMessage msg) {
            super(a, msg);
        }

        @Override
        protected void handleAgree(ACLMessage agree) {
            System.out.println(myAgent.getLocalName() + ": AGREE message received");
        }

        @Override
        protected void handleInform(ACLMessage inform) {
            System.out.println(myAgent.getLocalName() + ": Inform message received");
        }
        
        @Override
        protected void handleRefuse(ACLMessage refuse) {
            System.out.println(myAgent.getLocalName() + ": Refuse message received");
            
        }
        @Override
        protected void handleFailure(ACLMessage failure){
            System.out.println(myAgent.getLocalName() + ": Failure message received");
        }
    }

    @Override
    protected void takeDown() {
        try {
            DFService.deregister(this);
        } catch (FIPAException ex) {
            Logger.getLogger(CoalitionLeaderAgent.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
