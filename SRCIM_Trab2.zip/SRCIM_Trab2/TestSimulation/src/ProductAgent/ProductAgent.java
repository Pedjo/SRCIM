package ProductAgent;

import jade.core.Agent;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.ArrayList;
import java.util.LinkedList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author André
 */
public class ProductAgent extends Agent{
    
    protected LinkedList<String> mySkills;
    protected int productType;
    protected String source;
    protected String nextExecutor;
    protected String myLocation;

    @Override
    protected void setup() {
        Object[] args = getArguments();
        //Get skills to execute
        mySkills = (LinkedList<String>) args[0];        
               
        //Register in DF here
        
        //Launch Behaviour to manage Product Execution here
        
    }

    @Override
    protected void takeDown() {
        
    }
}
